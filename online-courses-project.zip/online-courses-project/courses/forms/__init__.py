from courses.forms.registration_forms import RegistrationForm
from courses.forms.login_forms import LoginForm