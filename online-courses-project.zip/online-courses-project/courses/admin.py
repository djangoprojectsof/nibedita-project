from django.contrib import admin
from courses.models.course import Course,Tag,Prerequisite,Learning
from courses.models.video import Video
from courses.models.payment import Payment
from courses.models.user_course import UserCourse
class TagAdmin(admin.TabularInline):
    model=Tag

class VideoAdmin(admin.TabularInline):
    model=Video

class PrerequisiteAdmin(admin.TabularInline):
    model=Prerequisite

class LearningAdmin(admin.TabularInline):
    model=Learning

class CourseAdmin(admin.ModelAdmin):
    inlines=[TagAdmin,LearningAdmin,PrerequisiteAdmin,VideoAdmin]



admin.site.register(Course,CourseAdmin)
admin.site.register(Video)
admin.site.register(UserCourse)
admin.site.register(Payment)

