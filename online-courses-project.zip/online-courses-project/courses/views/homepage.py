from django.shortcuts import HttpResponse
from django.shortcuts import render
from courses.models.course import Course,Learning,Prerequisite,Tag
from courses.models.video import Video

def home(request):
    courses=Course.objects.all()
    print(courses)
    return render(request,'courses/home.html',context={'courses':courses})
