from courses.views.homepage import home
from courses.views.courses import coursePage,my_courses
from courses.views.auth import SignupView,LoginView,signout
from courses.views.checkout import checkout,verifyPayment

